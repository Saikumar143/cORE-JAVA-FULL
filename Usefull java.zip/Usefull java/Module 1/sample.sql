CREATE OR REPLACE PROCEDURE 
	pr_ticket_details(p_empcode NUMBER) AS
	
	CURSOR ticket_cur IS 
		SELECT ticketcode,empcode,functions,category, description, raiseddate,status FROM ticket_details WHERE empcode = p_empcode;
	
	ticket_rec ticket_cur%ROWTYPE;
	invalid_empcode_exception EXCEPTION;
	v_count NUMBER;
BEGIN
	SELECT COUNT(*) INTO v_count FROM employee_details
	WHERE empcode = p_empcode;
	
	IF v_count = 0 THEN
		RAISE invalid_empcode_exception;
	END IF;
	DBMS_OUTPUT.PUT_LINE('Ticket ID	Employee ID	Function	Category	Desc	Status	Raised Date');
	OPEN ticket_cur;
	LOOP
		FETCH ticket_cur INTO ticket_rec;
		EXIT WHEN ticket_cur%NOTFOUND;
		DBMS_OUTPUT.PUT(ticket_rec.ticketcode||' ');
		DBMS_OUTPUT.PUT(ticket_rec.empcode||' ');
		DBMS_OUTPUT.PUT(ticket_rec.functions||' ');
		DBMS_OUTPUT.PUT(ticket_rec.category||' ');
		DBMS_OUTPUT.PUT(ticket_rec.description||' ');
		DBMS_OUTPUT.PUT(ticket_rec.status||' ');
		DBMS_OUTPUT.PUT_LINE(ticket_rec.raiseddate||' ');
	END LOOP;
EXCEPTION
	WHEN invalid_empcode_exception THEN
		DBMS_OUTPUT.PUT_LINE('Invalid Employee number:'|| p_empcode);
END pr_ticket_details;
/