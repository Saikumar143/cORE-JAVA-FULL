var catArr = [
['Select','Audio/Video/Web Presentation','Access Rights','Asset Allocation','Network','Printer',
],
['Select','Access Control','Air Conditioning','Food and Cafeteria','CCTV and Fire Alarm','House Keeping'],
['Select','Bus Transport','Cab Transport','Domestic Travel','International Travel']
];
function populateCategory(){
	var functs = frm1.functions;
	var selectedIdx = functs.selectedIndex;
	var cat = frm1.category;
	
	if(selectedIdx==0){
		alert("Please select the function...");
	}else{
		while (cat.hasChildNodes()){
			cat.removeChild(cat.lastChild);
		}
		for(i=0;i<catArr[selectedIdx-1].length;i++){
			var ele = document.createElement('option');
			ele.textContent=catArr[selectedIdx-1][i];
			ele.value=catArr[selectedIdx-1][i];
			cat.appendChild(ele);
		}
	}
}
function validateForm(){
	if(validateMultiple()&&validateDate()){
		alert("All data validated");
		return true;
	}

}

function validateDate(){
	var rDateStr = frm1.raisedDate.value;
	var rDate = new Date(rDateStr);
	var today = new Date();
	if(today.getDate()==rDate.getDate() &&
		today.getMonth()==rDate.getMonth() &&
		today.getYear()==rDate.getYear()){
			return true;
	}else{
		alert("Raised date should be today's Date");
		return false;
	}
}
function validateMultiple(){
	var mult = frm1.multiple.checked;
	if(mult){
		alert('Multiple users / Systems Impacted');
	}
	return true;
}